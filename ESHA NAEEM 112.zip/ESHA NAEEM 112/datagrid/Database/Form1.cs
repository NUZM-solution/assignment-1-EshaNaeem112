﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Database
{
    public partial class Form1 : Form
    {
        private object dt;

        public Form1()
        {
            InitializeComponent();
        }
         public void createnewrow()
 {
            
                { 
      DataColumn dc1 = new DataColumn("Course Code", typeof(int));
     DataColumn dc2 = new DataColumn("Course Title", typeof(string));
      DataColumn dc3 = new DataColumn("Grade", typeof(string));
      DataColumn dc4 = new DataColumn("Status", typeof(int));
      DataColumn dc5 = new DataColumn("Obtained Marks", typeof(string));
      dt.Columns.Add(dc1);
      dt.Columns.Add(dc2);
      dt.Columns.Add(dc3);
      dt.Columns.Add(dc4);
      dt.Columns.Add(dc5);
            dt.Rows.Add(textCode.Text, textTitle.Text, textGrade.Text, textStatus.Text, textMarks.Text);
	dataGridView1.DataSource = dt;	
	}

    private void btn_Enter_Click(object sender, EventArgs e)
          {
                    createnewrow();
                    }


            }

            private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
    }
