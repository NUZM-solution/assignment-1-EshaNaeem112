﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace studentform
{
    public partial class Login : Form
    {
        Double count = 0;
        public Login()

        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
             textpass.Clear();
            textuser.Clear();
            textuser.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string user, pass;
            user = "root";
            pass = "password";

            if ((textuser.Text == user) && (textpass.Text == pass))
            {
                MessageBox.Show("Welcome User");
            }
            else
            {


                count = count + 1; double maxcount = 3; double remain;
                remain = maxcount - count;
                MessageBox.Show("Wrong user name or password" + "\t" + remain + "" + "tries left");
                textpass.Clear();
                textuser.Clear();
                textuser.Focus();
                if (count == maxcount)
                {
                    MessageBox.Show("Max try exceeded."); Application.Exit();
                //}


            }
        }

        private void textpass_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
